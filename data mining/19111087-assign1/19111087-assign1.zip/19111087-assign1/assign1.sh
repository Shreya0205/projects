python3 q1.py

bash case-generator.sh
bash edge-generator.sh
bash neighbor-generator.sh
bash state-generator.sh
bash zscore-generator.sh
bash method-spot-generator.sh
bash top-generator.sh
