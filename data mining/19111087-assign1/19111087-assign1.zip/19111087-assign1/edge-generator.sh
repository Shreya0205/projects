python3 q3.py
