python3 q8.py
