python3 q7.py

