python3 q4.py
