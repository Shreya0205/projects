python3 q2.py
